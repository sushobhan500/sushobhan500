
public class Q3 {

	public static void main(String[] args) {
		double primitiveDouble = 45.5;
        Double autoBoxedDouble = primitiveDouble;
        System.out.println("Autoboxed Integer: " +autoBoxedDouble);

        Double doubleWithConstructor = new Double( primitiveDouble);
        System.out.println("Integer with Constructor: " + doubleWithConstructor);

	}

}
