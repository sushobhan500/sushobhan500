
public class Q4 {

	public static void main(String[] args) {
		boolean primitiveBoolean = 1<2;
        Boolean autoBoxedBoolean = primitiveBoolean;
        System.out.println("Autoboxed Integer: " +autoBoxedBoolean);

        Boolean booleanWithConstructor = new Boolean(primitiveBoolean);
        System.out.println("Integer with Constructor: " +  booleanWithConstructor); 

	}

}
