package viper;
        public class Q9{
	    public static void main(String[] args) {
	      
	        int intValue = 10;
	        float floatValue = 10.5f;
	        double doubleValue = 20.5;
	        boolean booleanValue = true;
	        
	       
	        Integer intObject = Integer.valueOf(intValue);
	        Float floatObject = Float.valueOf(floatValue);
	        Double doubleObject = Double.valueOf(doubleValue);
	        Boolean booleanObject = Boolean.valueOf(booleanValue);
	        
	       
	        System.out.println("Integer object: " + intObject);
	        System.out.println("Float object: " + floatObject);
	        System.out.println("Double object: " + doubleObject);
	        System.out.println("Boolean object: " + booleanObject);
	        
	    
	        int intPrimitive = intObject.intValue();
	        float floatPrimitive = floatObject.floatValue();
	        double doublePrimitive = doubleObject.doubleValue();
	        boolean booleanPrimitive = booleanObject.booleanValue();
	        
	        
	        System.out.println("\nPrimitive values:");
	        System.out.println("int value: " + intPrimitive);
	        System.out.println("float value: " + floatPrimitive);
	        System.out.println("double value: " + doublePrimitive);
	        System.out.println("boolean value: " + booleanPrimitive);
	    }
	}

