package viper;

public class Q7 {

}
