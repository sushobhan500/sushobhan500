package viper;
		class Q1 {
		    public static void main(String[] args) {
		    	        int primitiveInt = 42;
		    	        Integer autoBoxedInteger = primitiveInt;
		    	        System.out.println("Autoboxed Integer: " + autoBoxedInteger);

		    	        Integer integerWithConstructor = new Integer(primitiveInt);
		    	        System.out.println("Integer with Constructor: " + integerWithConstructor);
		    	    }
		    	}

		
