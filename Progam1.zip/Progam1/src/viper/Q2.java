
public class Q2 {
	public static void main(String[] args) {
		float primitiveFloat = 42.3f;
        Float autoBoxedFloat = primitiveFloat;
        System.out.println("Autoboxed Integer: " +autoBoxedFloat);

        Float floatWithConstructor = new Float(primitiveFloat);
        System.out.println("Integer with Constructor: " + floatWithConstructor);

	}

}
