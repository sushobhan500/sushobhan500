package viper;

public class Q10 {

}
